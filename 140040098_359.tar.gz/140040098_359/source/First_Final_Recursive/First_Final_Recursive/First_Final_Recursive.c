#include "Motion_Command.c"
#include "Sensor_Reading.c"
#include "Velocity_Control.c"
#include "Position_Control.c"
#include "Buzzer_Control.c"


int obstacle_distance, sensor_left, sensor_right, sensor_middle;

int initx=0, inity=-1;								// Giving initial point coordinates
int x=0, y=-1;										// x and y are the current point coordinates
int finalx=2, finaly=1 ;							// Giving final point coordinates
int frequency[9][9];								// This array is to store the number of times bot comes to a particular point
int pathx[81], pathy[81];							// These arrays are to remember the shortest path back to the initial point
int i=-1;											// This is used later in the code



//Function to Initialize PORTS
void port_init()
{
	lcd_port_config();
	adc_pin_config();
	motion_pin_config();
	left_encoder_pin_config(); //left encoder pin config
	right_encoder_pin_config(); //right encoder pin config
	buzzer_pin_config();
}


void init_devices (void)
{
	cli(); //Clears the global interrupts
	port_init();
	adc_init();
	timer5_init();
	left_position_encoder_interrupt_init();
	right_position_encoder_interrupt_init();
	sei(); //Enables the global interrupts
}


void gotopoint(int m, int n){									// Function to go to the next point while coming back in the shortest path.
	if(x<m){turntowards('E');}									// Takes a decision at every junction to which direction it has to turn.
	else{
	if(x>m){turntowards('W');}
	else{
	if(y<n){turntowards('N');}
	else{
	if(y>n){turntowards('S');}}}}
	while (1){															// Loop continues until the bot reaches the next junction and then breaks 
																		// out of the loop and the function.	
		
		sensor_left=ADC_Conversion(3);
		sensor_middle=ADC_Conversion(2);
		sensor_right=ADC_Conversion(1);
		
	if(sensor_middle<20 && sensor_right>20 && sensor_left>20) forward();
	else{
		if(sensor_right<20 && sensor_left>20) soft_right();
		else{
			if(sensor_left<20 && sensor_right>20) soft_left();
			else{
				if(sensor_right<20 && sensor_middle<20 && sensor_left<20) {
					stop();
					break;
}}}}}}



void distance_calculate(void){						// Function to calculate and store the obstacle distance.
	
	sharp = ADC_Conversion(11);						//Stores the Analog value of front sharp connected to ADC channel 11 into variable "sharp"
	obstacle_distance = Sharp_GP2D12_estimation(sharp);				//Stores Distance calculated in a variable "value".
	lcd_print(2,14,obstacle_distance,3); 						//Prints Value Of Distance in MM measured by Sharp Sensor.
}


void print_direction(void){							// Function to print the Direction the bot is facing, on the LCD screen. 
	lcd_cursor(1,1);
	if(Direction=='N') lcd_string("N");
	else{
	if(Direction=='E') lcd_string("E");
	else{
	if(Direction=='W') lcd_string("W");
	else{
	if(Direction=='S') lcd_string("S");
}}}}



void coordinate_mapping(int *a, int *b){				// Function is to be called on reaching a junction and then evaluates the coordinates of that point  
	if(Direction=='N') (*b)++;							// depending on the direction and the previous coordinates.
	else{
	if(Direction=='E') (*a)++;	
	else{
	if(Direction=='W') (*a)--;
	else{
	if(Direction=='S') (*b)--;
	}}}
		
}


void turn_decision(x,y,finalx,finaly){					// The main part of the program where the bot takes a decision so as which direction to turn
														// depending on the current point, final point coordinates and the frequency of the point.	
	if(x==finalx && y==finaly){stop();}
	else{
		if(x<finalx&&y<finaly){
			switch (frequency[x][y]%4)
			{
			case 1:		turntowards('N');
				break;
			case 2:		turntowards('E');
				break;
			case 3:		turntowards('S');
				break;
			case 0:		turntowards('W');
				break;
			}
		}
		else{
		if (x<finalx&&y==finaly){
			switch (frequency[x][y]%4)
			{
				case 1:		turntowards('E');
				break;
				case 2:		turntowards('N');
				break;
				case 3:		turntowards('S');
				break;
				case 0:		turntowards('W');
				break;
			}
		}		
		else{
			if (x<finalx&&y>finaly){
				switch (frequency[x][y]%4)
				{
					case 1:		turntowards('S');
					break;
					case 2:		turntowards('E');
					break;
					case 3:		turntowards('N');
					break;
					case 0:		turntowards('W');
					break;
				}
		}						
		else{
			if (x==finalx&&y<finaly){
				switch (frequency[x][y]%4)
				{
					case 1:		turntowards('N');
					break;
					case 2:		turntowards('E');
					break;
					case 3:		turntowards('W');
					break;
					case 0:		turntowards('S');
					break;
				}
		}
		else{
			if (x==finalx&&y>finaly){
				switch (frequency[x][y]%4)
				{
					case 1:		turntowards('S');
					break;
					case 2:		turntowards('E');
					break;
					case 3:		turntowards('W');
					break;
					case 0:		turntowards('N');
					break;
				}
		}
		else{
			if (x>finalx&&y<finaly){
				switch (frequency[x][y]%4)
				{
					case 1:		turntowards('N');
					break;
					case 2:		turntowards('W');
					break;
					case 3:		turntowards('S');
					break;
					case 0:		turntowards('E');
					break;
				}
		}
		else{
			if (x>finalx&&y==finaly){
				switch (frequency[x][y]%4)
				{
					case 1:		turntowards('W');
					break;
					case 2:		turntowards('N');
					break;
					case 3:		turntowards('S');
					break;
					case 0:		turntowards('E');
					break;
				}
		}
		else{
			if (x>finalx&&y>finaly){
				switch (frequency[x][y]%4)
				{
					case 1:		turntowards('S');
					break;
					case 2:		turntowards('W');
					break;
					case 3:		turntowards('N');
					break;
					case 0:		turntowards('E');
					break;
				}
}}}}}}}}}}



void turntowards(char z){					// Function to make the bot turn in the proper direction received from the turn_decision function.
	if (Direction==z){stop;}
	else{
		if(Direction=='N'){
			switch (z)
			{
			case 'E': right_degrees(95);
			break;
			case 'W': left_degrees(95);
			break;
			case 'S': right_degrees(95);
					  right_degrees(95);
			break;
			}
		}
		else  {
		if(Direction=='E'){
			switch (z)
			{
			case 'S': right_degrees(95);
			break;
			case 'N': left_degrees(95);
			break;
			case 'W': right_degrees(95);
					  right_degrees(95);
			break;
			}
		}
		else{
		if(Direction=='W'){
			switch (z)
			{
				case 'N': right_degrees(95);
				break;
				case 'S': left_degrees(95);
				break;
				case 'E': right_degrees(95);
						  right_degrees(95);
				break;
			}
		}
		else{
		if(Direction=='S'){
			switch (z)
			{
				case 'W': right_degrees(95);
				break;
				case 'E': left_degrees(95);
				break;
				case 'N': right_degrees(95);
						  right_degrees(95);
				break;
			}
		}
}}}}}



void movement(void){									// This function executes when the bot reaches a junction.
			
		
		lcd_print(1,3,x,1);
		lcd_print(1,5,y,1);
		(frequency[x][y])++;
		if(x==finalx && y==finaly){stop();
		}
		else{
		turn_decision(x,y,finalx,finaly);
		stop();
		print_direction();
		distance_calculate();
		
	
	}}



//Main Function
int main(void)
{
	
	init_devices();
	lcd_set_4bit();
	lcd_init();
	
	for(int j=0; j<9; j++){								// Declaring frequency of all points to be zero.
		for(int k=0; k<9; k++){
			frequency[j][k]=0;
		}
	}
	
	pathx[0]=0;
	pathy[0]=0;
	
	Direction='N';
	
	
	
	while(1)
	{	
		

		print_sensor(2,2,3);							//Prints value of White Line Sensor1
		print_sensor(2,6,2);							//Prints Value of White Line Sensor2
		print_sensor(2,10,1);							//Prints Value of White Line Sensor3

		

		distance_calculate();
		
		
		sensor_left=ADC_Conversion(3);
		sensor_middle=ADC_Conversion(2);
		sensor_right=ADC_Conversion(1);
		
	
		if(sensor_middle<20 && sensor_right>20 && sensor_left>20) forward();			// Function for white line movement of the bot.
		else{
		if(sensor_right<20 && sensor_left>20) soft_right();
		else{
		if(sensor_left<20 && sensor_right>20) soft_left();
		else{
		if(sensor_right<20 && sensor_middle<20 && sensor_left<20) {
						stop();
						coordinate_mapping(&x,&y);
						forward_mm(93);
						stop();
						for(int k=i; k>=0; k--){                         // storing current point coordinates to remember the shortest path.
						if(pathx[k]==x && pathy[k]==y){i=k;}
					}
					i++;
					pathx[i]=x;
					pathy[i]=y;
					
					if(x==finalx && y==finaly){break;}
						a: movement();
						
						if(obstacle_distance<220) goto a;
						
						
						
				}}}}
				
					
}


							lcd_cursor(1,1);						// Acknowledgement on reaching the final point.
							lcd_string("..Final--Point..");
							lcd_cursor(2,1);
							lcd_string("....Reached.....");
							_delay_ms(1000);
							for(int l=0; l<3; l++){
							buzzer_on();
							_delay_ms(500);
							buzzer_off();
							_delay_ms(500);
							}			
							
							lcd_cursor(1,1);
							lcd_string(" On My Way Back ");
										


for(int j=i-1; j>=0; j--){					// Function to return to the initial point in the shortest path already stored.
	
	gotopoint(pathx[j],pathy[j]);
	coordinate_mapping(&x,&y);
	lcd_print(2,3,x,1);
	lcd_print(2,5,y,1);
	if(x==initx&&y==inity-1){break;}
	forward_mm(93);
	stop();
	
}			


for(int l=0; l<3; l++){				//Function on reaching the initial point. 
	buzzer_on();
	_delay_ms(800);
	buzzer_off();
	_delay_ms(800);
}


}